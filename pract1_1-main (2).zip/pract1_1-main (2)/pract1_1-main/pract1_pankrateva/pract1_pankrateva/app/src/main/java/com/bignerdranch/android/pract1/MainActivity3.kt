package com.bignerdranch.android.pract1

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity3 : AppCompatActivity() {
    lateinit var vivodm:TextView
    lateinit var vivodr:TextView
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        vivodm = findViewById(R.id.vivodmetrov)
        vivodr = findViewById(R.id.vivodres)

        val vm = intent.getIntExtra("kolvometr", 0)
        val vr = intent.getStringExtra("result")
        vivodm.text = " $vm"
        vivodr.text = " $vr"
    }

    fun nazad(view: View) {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }
}